import * as db from './transcriptManager'

// jest doesn't have a good equivalent to assert.sameMembers(), so we'll use these instead
function expectSubset<T> (set1:T[],set2:T[]) {set1.forEach(s1 => expect(set2).toContainEqual(s1))}
function expectSameMembers(set1,set2) {
    expectSubset(set1,set2);
    expectSubset(set2,set1)
}

function test1 () {
    db.initialize();
    const id1 = db.addStudent("Alonzo");
    const id2 = db.addStudent("Barbara");
    const id3 = db.addStudent("Barbara");
    const ids = db.getStudentIDs("Barbara")
    expectSameMembers(ids, [id2,id3])
    db.addGrade(id1,"cs100",85)
    expect(db.getGrade(id1,"cs100")).toEqual(85)
    expect(() => db.addGrade(id1, "cs100",85)).toThrow()
}

// not testing all the error behaviors yet.

// test deleteStudent
function testDeleteStudent() {
    db.initialize();
    const idAlonzo1 = db.addStudent("Alonzo")
    const idAlonzo2 = db.addStudent("Alonzo")
    const ids = db.getStudentIDs("Alonzo")
    expectSameMembers(ids, [idAlonzo1, idAlonzo2])      
    db.deleteStudent(idAlonzo1);
    expectSameMembers(
        db.getStudentIDs("Alonzo"),
        [idAlonzo2])
    
}

describe("first tests", () => {
    test("first test", test1)
    test("test of delete", testDeleteStudent)
})

describe("tests of addStudent", () => {
    test("addStudent returns an ID", () => {
        db.initialize()
        const newID = db.addStudent("jack")
        expect(newID).toBeGreaterThan(0)
    })
    test("newStudent shows up among studentIDs", () => {
        db.initialize()
        const newID = db.addStudent("jack")
        const jackIDs = db.getStudentIDs("jack")
        expect(jackIDs).toContain(newID)
    })
    test("new students with same name get different IDs", () => {
        db.initialize()
        const neel1 = db.addStudent("neel")
        const neel2 = db.addStudent("neel")
        expect(neel1).not.toEqual(neel2)
    })
    test("student name must not be empty", () => {
        db.initialize()
        expect(() => db.addStudent("")).toThrow()
    })
    test("student ID must not have occurred already", () => {
        db.initialize();
        const allIDs = db.getAll().map(transcript => transcript.student.studentID)
        const rahulID = db.addStudent("rahul")
        expect(allIDs).not.toContain(rahulID)            
    })


})