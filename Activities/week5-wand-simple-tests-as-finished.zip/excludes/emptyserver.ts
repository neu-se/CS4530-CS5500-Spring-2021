import * as express from 'express'
import * as cors from 'cors'

// create the server, call it app
const app: express.Application = express();

// the port to listen on
const inputPort = 4001

// initializes the server
function initalizeServer () {
    console.log(`Express server now listening on localhost:${inputPort}`)
}


// start the server listening on 4001
app.listen(inputPort,initalizeServer)

// install middleware

// allow requests from any port or source.
app.use(cors())

// parse application.json
app.use(express.json({type: 'json'}));

// POST parameters in the body will be application/x-www-urlencoded
app.use(express.urlencoded({extended: true}))

// for parsing application/json
app.use(express.json());

// for parsing application/x-www-form-urlencoded
// converts foo=bar&baz=quux to {foo: 'bar', baz: 'quux'}
app.use(express.urlencoded({ extended: true })); 

// install routes


 



