# Sample REST app using express.js

# Goal:

Create a web-based database for student transcripts.

## Data Model

type Student = {studentID: number, studentName: string}
type CourseGrade = {course:string,grade:number}
type Transcript = {student:Student, grades:Grades[]}
// doesn't keep track of semesters.
We'll keep a list of Transcripts, with studentID as key

## REST Endpoints

* POST /student    -- adds a new student to the database, returns an ID for this student. Requires a post parameter 'name'. Multiple students may have the same name.
* GET  /transcripts/:ID           -- returns name transcript for student with given ID.  Fails if no such student
* GET  /studentids?name=string     -- returns list of IDs for student with the given name
* DELETE /students/:ID          -- deletes transcript for student with the given ID, fails if no such student

* POST /coursegrades/:studentID/:course   -- adds an entry in this student's transcript with given name and course.  Requires a post parameter 'grade'. Fails if there is already an entry for this course in the student's transcript 
* GET /coursegrades/:studentID/:course  -- returns the student's grade in the specified course.  Fails if student or course is missing.
   


