
# Weather Station Observer Pattern Example
This project contains starter code to demonstrate the *observer* design pattern.

To run it on your computer, run `npm install` to fetch the dependencies for the project, and then run
`ts-node src/WeatherStation.ts` (or `npm run demo`, if `ts-node` does not work), which should produce the following output:
```
Current conditions: 80F degrees and 65% humidity
Avg/max/min temperature = 80/80/0
Heat Index: 82.95535063710001
Forecast: Improving weather on the way!
Current conditions: 82F degrees and 70% humidity
Avg/max/min temperature = 81/82/0
Heat Index: 86.90123306385205
Forecast: Watch out for cooler, rainy weather
Current conditions: 78F degrees and 90% humidity
Avg/max/min temperature = 80/82/0
Heat Index: 83.64967139559604
Forecast: More of the same
```

As we discussed in class, there is a lot to be improved from this design. Working in your group,
modify this code so that it uses the observer pattern, with each of the various display classes as
the observers, and the `WeatherData` as the subject object.

A high-level sketch of this design is:
1. Create a `WeatherDataObserver` interface, which defines your `update` method
1. Create an `observers` array in `WeatherData` and helper methods to register and de-register observers. Add code to notify the observers of updates when the weather data updates.
1. Modify each of `CurrentConditionsDisplay`, `ForecastDisplay`, `HeatIndexDisplay` and `StatisticsDisplay` to be implementors of the new observer interface. These display classes should display their information whenever the weather data is updated.
1. Modify `WeatherStation`, removing all of the `displayXXX` calls, so that it instead simply creates the `WeatherData`, the `Display`s, and updates the weather data

When you are done, run `npm run pack` to create a zip archive with your code and post it on Slack, along with the message "Breakout Room X: breakout room members"

This activity is based on the running example in Chapter 2 of "Head First Design Patterns, 2nd Edition" by Robson and Freeman.

### Instructor Notes

Here are some nice points to discuss:
* Coupling is reduced: subject doesn't know anything about observer. Can add new observers dynamically, do not need to modify subject to add new types of observers.
* Note "Listener" vs "Observer" - more or less the same thing, different words
* Why separate `update` and `display` in the observers? Perhaps an over-aggressive application of single responsibility principle.
* Here's something that's only vaguely specified and could cause a bug later: did we make any implicit assumptions about the order of observer notification? Everyone probably used an array, so it will be deterministic, but warn that may not always be case. Java's Observer does not guarantee order.
* Should the observers take the subject as a parameter to the constructor, which
would let us enforce that each observer is tied to exactly one subject? (Downsides: Can't
have an observer on more than one subject, have now written `new StatisticsDisplay()` and discarded the return value)
* What about writing the observers as just functions that conform to the type `(currentData:WeatherData) => void` ? That's cool, but doesn't let us have stateful observers.
* Note significance of reading properties off of `weatherData` immediately in the `updated` function, and not caching the `weatherData` object: the pattern
suggests that the values are up-to-date when `update` is called, might be mutated later, could have unexpected results if were caching the whole object.
