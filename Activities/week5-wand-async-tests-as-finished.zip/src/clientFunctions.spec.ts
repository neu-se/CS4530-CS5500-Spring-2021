import * as client from './clientFunctions';
import Express from 'express';
import * as http from "http";
import transcriptServer from "./transcriptServer";
import {AddressInfo} from "net";
import {setBaseURL} from './remoteService'
import * as db from "./transcriptManager";


async function checkGrade(studentName, course, assignedGrade) {
  await db.addGrade(studentName, course, assignedGrade)
  const reportedGrade = await db.getGrade(studentName, course)
  expect(reportedGrade).toBe(assignedGrade)
}


/*
Tests for the Transcript Manager. This test suite automatically deploys a local testing server and
cleans it up when it's done
 */
describe('clientFunctions.ts', () => {
  let server: http.Server;



  beforeAll(async () => {
    // Deploy a testing server
    const app = Express();
    server = http.createServer(app);
    // Add the transcript server's routes to the express server
    transcriptServer(app);

    db.initialize();

    // Start the server on a random, free port, then fetch that address and configure the client to use that server.
    await server.listen();
    const address = server.address() as AddressInfo;
    setBaseURL(`http://127.0.0.1:${address.port}`);
  });

  afterAll(async () => {
    // After all tests are done, shut down the server to avoid any resource leaks
    await server.close();
  })

  beforeEach(() => {
    // Before any test runs, clean up the datastore.
    // Is this enough to make sure that tests are hermetic?  Discuss.
    return db.initialize();
  })

  describe('addStudent API', () => {
    test('should return an ID', async () => {
      const createdStudent = await client.addStudent('Avery');
      expect(createdStudent.studentID).toBeGreaterThan(0);
    });
    test("newStudent shows up among studentIDs", async () => {
      db.initialize()
      const jackID = await db.addStudent("jack")
      const jackIDs = await db.getStudentIDs("jack")
      expect(jackIDs).toContain(jackID)
    })

    test('should allow multiple students to have the same name, giving them different IDs', async () => {
      // Create 2 new Avery entries
      const [createdAvery1, createdAvery2] = await Promise.all([
        client.addStudent('Avery'),
        client.addStudent('Avery')
      ]);
      expect(createdAvery2.studentID).not.toEqual(createdAvery1.studentID);
      // Fetch all Avery entries
      const ids = await client.getStudentIDs('Avery');

    });

    test("student ID must not have occurred already", async () => {
      const allIDs = await db.getAll().map(transcript => transcript.student.studentID)
      const rahulID = await db.addStudent("rahul")
      expect(allIDs).not.toContain(rahulID)
    })
  })

describe("addGrade/getGrade API", async () => {

  test('reported grade is the same as assigned grade', async () => {
    checkGrade('vikram',"cs100",72)
    checkGrade('ankita','cs100',96)
    checkGrade('ankita','cs101',92)   
  })

})


  describe('deleteStudent API', () => {
    test('should remove a deleted student from the list of students', async () => {

    });
  })

}) 
