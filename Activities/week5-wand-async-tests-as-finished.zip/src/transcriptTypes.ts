// types as they are made visible to the client.
// internally, the transcript manager may use different representations
// of these quantities.

export type StudentID = number;
export type Student = { studentID: number, studentName: string };
export type Course = string;
export type CourseGrade = { course: Course, grade: number };
export type Transcript = { student: Student, grades: CourseGrade[] };
