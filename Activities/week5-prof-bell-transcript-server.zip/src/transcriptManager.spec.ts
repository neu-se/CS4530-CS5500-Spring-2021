import * as client from './client';
import Express from 'express';
import * as http from "http";
import transcriptServer from "./transcriptServer";
import {AddressInfo} from "net";
import {setBaseURL} from './remoteService'
import * as db from "./transcriptManager";

/*
Tests for the Transcript Manager. This test suite automatically deploys a local testing server and
cleans it up when it's done
 */
describe('TranscriptManager', () => {
  let server: http.Server;

  beforeAll(async () => {
    // Deploy a testing server
    const app = Express();
    server = http.createServer(app);
    // Add the transcript server's routes to the express server
    transcriptServer(app);

    db.initialize();

    // Start the server on a random, free port, then fetch that address and configure the client to use that server.
    await server.listen();
    const address = server.address() as AddressInfo;
    setBaseURL(`http://127.0.0.1:${address.port}`);
  });

  afterAll(async () => {
    // After all tests are done, shut down the server to avoid any resource leaks
    await server.close();
  })

  beforeEach(() => {
    // Before any test runs, clean up the datastore. This should ensure that tests are hermetic.
    db.initialize();
  })

  describe('Create student', () => {
    it('should return an ID', async () => {
      const createdStudent = await client.addStudent('Avery');
      expect(createdStudent.studentID).toBeGreaterThan(4);
    });
  })

  describe('Posting grades', () => {
    it('should not accept grades for invalid student IDs', async () => {

    });
    it('should accept grades for students ', async () => {

    });
  })

  describe('Full-system tests', () => {
      it('should allow multiple students to have the same name, giving them different IDs', async () => {
        // Create 2 new Avery entries
        const [createdAvery1, createdAvery2] = await Promise.all([
          client.addStudent('Avery'),
          client.addStudent('Avery')
        ]);
        expect(createdAvery2.studentID).not.toBe(createdAvery1.studentID);
        // Fetch all Avery entries
        const ids = await client.getStudentIDs('Avery');
        // Make sure the 2 created ones are both listed
        expect(ids).toContain(createdAvery1.studentID);
        expect(ids).toContain(createdAvery2.studentID);
      });
      it('should remove a deleted student from the list of students', async () => {

      });
    }
  );
});
