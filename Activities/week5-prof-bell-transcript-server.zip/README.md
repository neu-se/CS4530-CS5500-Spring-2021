# Testing a REST API using Jest

This project contains our typical Transcript Server + Client, and is configured with a few starter tests. The goal of this activity is for you to practice writing tests that exercise a (provided) specification, and also for you to practice deriving tests for an API based on its specification.

The starter tests are in `transcriptManager.spec.ts`, and can be run with `npm test`.

The API that we are testing is defined in `client.ts`, and consists of these methods:
```ts
/*
 POST /transcripts
 -- adds a new student to the database, returns an ID for this student.
 -- Requires a post parameter 'name'.
 -- Multiple students may have the same name.
 */
export async function addStudent(studentName: string): Promise<{ studentID: number }> ;

/*
 GET  /transcripts/:ID           -
- returns name transcript for student with given ID.  Fails if no such student
*/
export async function getTranscript(studentID: number): Promise<Transcript> ;

/*
GET  /studentids?name=string     -- returns list of IDs for student with the given name
*/
export async function getStudentIDs(studentName: string): Promise<StudentID[]> ;

/*
DELETE /transcripts/:ID
-- deletes transcript for student with the given ID, fails if no such student
*/
export async function deleteStudent(studentID: StudentID): Promise<void>;

/* POST /transcripts/:studentID/:course   -- /transcripts
-- adds an entry in this student's transcript with given name and course.
-- Requires a post parameter 'grade'. Fails if there is already an entry for this course in the student's transcript
*/
export async function addGrade(studentID: StudentID, course: Course, grade: number)
  : Promise<{ grade: number }> ;

// GET /transcripts/:studentID/:course
// returns the student's grade in the specified course as a
// TS object.
// Fails if student or course is missing.
export async function getGrade(studentID: StudentID, course: Course);

// * GET /transcripts     -- returns list of all transcripts
export async function getAllTranscripts(): Promise<Transcript[]> ;

```
