// Do not touch this file - the autograder will use a different implementation of this file

// @ts-ignore
export function ConfigureTest(testID: string): string[] {
  return ['No fault'];
}

// @ts-ignore
export function StartTest(testID: string): void {
}
