
export function ConfigureTest(testID: string): string[] {
  return ['No fault'];
}

export function StartTest(testID: string): void {
}
