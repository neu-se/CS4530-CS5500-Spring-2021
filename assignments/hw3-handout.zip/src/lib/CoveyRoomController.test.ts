import {mock, mockReset} from 'jest-mock-extended';
import {Socket} from 'socket.io';
import {nanoid} from 'nanoid';
import TwilioVideo from './TwilioVideo';
import CoveyRoomListener from '../types/CoveyRoomListener';
import CoveyRoomController from './CoveyRoomController';
import CoveyRoomsStore from './CoveyRoomsStore';
import Player from '../types/Player';
import {roomSubscriptionHandler} from '../requestHandlers/CoveyRoomRequestHandlers';
import * as TestUtils from '../TestUtils';

// Set up a manual mock for the getTokenForRoom function in TwilioVideo
jest.mock('./TwilioVideo');
const mockGetTokenForRoom = jest.fn();
// eslint-disable-next-line
// @ts-ignore it's a mock
TwilioVideo.getInstance = () => ({
  getTokenForRoom: mockGetTokenForRoom,
});

describe('CoveyRoomController', () => {
  beforeEach(() => {
    // Reset any logged invocations of getTokenForRoom before each test
    mockGetTokenForRoom.mockClear();
  });
  it('constructor should set the friendlyName property', () => {
  });
  describe('addPlayer', () => {
    it('should use the coveyRoomID and userName properties when requesting a video token',
      async () => {
      });
  });
  describe('room listeners and events', () => {
    // Set up mock room listeners, you will likely find it useful to use these in the room listener tests.
    // Feel free to change these lines as you see fit, or leave them and use them as-is
    const mockListeners = [mock<CoveyRoomListener>(),
      mock<CoveyRoomListener>(),
      mock<CoveyRoomListener>()];
    beforeEach(() => {
      mockListeners.forEach(mockReset);
    });
    it('should notify added listeners of player movement when updatePlayerLocation is called', async () => {
    });
    it('should notify added listeners of player disconnections when destroySession is called', async () => {
    });
    it('should notify added listeners of new players when addPlayer is called', async () => {
    });
    it('should notify added listeners that the room is destroyed when disconnectAllPlayers is called', async () => {
    });
    it('should not notify removed listeners of player movement when updatePlayerLocation is called', async () => {
    });
    it('should not notify removed listeners of player disconnections when destroySession is called', async () => {
    });
    it('should not notify removed listeners of new players when addPlayer is called', async () => {
    });
    it('should not notify removed listeners that the room is destroyed when disconnectAllPlayers is called', async () => {
    });
  });
  describe('roomSubscriptionHandler', () => {
    /* Set up a mock socket, which you may find to be useful for testing the events that get sent back out to the client
    by the code in CoveyRoomController calling socket.emit('event', payload) - if you pass the mock socket in place of
    a real socket, you can record the invocations of emit and check them.
     */
    const mockSocket = mock<Socket>();
    /*
    Due to an unfortunate design decision of Avery's, to test the units of CoveyRoomController
    that interact with the socket, we need to: 1. Get a CoveyRoomController from the CoveyRoomsStore, and then 2: call
    the roomSubscriptionHandler method. Ripley's provided some boilerplate code for you to make this a bit easier.
     */
    let testingRoom: CoveyRoomController;
    beforeEach(async () => {
      const roomName = `connectPlayerSocket tests ${nanoid()}`;
      // Create a new room to use for each test
      testingRoom = CoveyRoomsStore.getInstance().createRoom(roomName, false);
      // Reset the log on the mock socket
      mockReset(mockSocket);
    });
    it('should reject connections with invalid room IDs by calling disconnect', async () => {
      /* Hint: see the beforeEach in the 'with a valid session token' case to see an example of how to configure the
         mock socket and connect it to the room controller
       */
    });
    it('should reject connections with invalid session tokens by calling disconnect', async () => {
      /* Hint: see the beforeEach in the 'with a valid session token' case to see an example of how to configure the
         mock socket and connect it to the room controller
       */
    });
    describe('with a valid session token', () => {
      /*
        Ripley says that you might find this helper code useful: it will create a valid session, configure the mock socket
        to identify itself with those tokens, and then calls the roomSubscriptionHandler on the mock socket.

        Your tests should perform operations on testingRoom, and make expectations about what happens to the mock socket.
       */
      let connectedPlayer;
      beforeEach(async () => {
        connectedPlayer = new Player(`test player ${nanoid()}`);
        const session = await testingRoom.addPlayer(connectedPlayer);
        TestUtils.setSessionTokenAndRoomID(testingRoom.coveyRoomID, session.sessionToken, mockSocket);
        roomSubscriptionHandler(mockSocket);
      });
      it('should add a room listener, which should emit "newPlayer" to the socket when a player joins', async () => {
      });
      it('should add a room listener, which should emit "playerMoved" to the socket when a player moves', async () => {
      });
      it('should add a room listener, which should emit "playerDisconnect" to the socket when a player disconnects', async () => {
      });
      it('should add a room listener, which should emit "roomClosing" to the socket and disconnect it when disconnectAllPlayers is called', async () => {
      });
      describe('when a socket disconnect event is fired', () => {
        /* Hint: find the on('disconnect') handler that CoveyRoomController registers on the socket, and then
           call that handler directly to simulate a real socket disconnecting.
           */
        it('should remove the room listener for that socket, and stop sending events to it', async () => {

        });
        it('should destroy the session corresponding to that socket', async () => {

        });
      });
      it('should forward playerMovement events from the socket to subscribed listeners', async () => {
        /* Hint: find the on('playerMovement') handler that CoveyRoomController registers on the socket, and then
           call that handler directly to simulate a real socket sending a user's movement event.
           */
      });
    });
  });
});
