import React, { useState } from "react";

export interface GreetOptions {
    name : string;
    level : number;
}
export const Greet = (options:GreetOptions) => {
    const [formal, setFormal] = useState(true);
    if (formal) {
        return <p>Hello {options.name}, how do you do?</p>
    } else {
        return <p>Hi {options.name}, what's up?</p>
    }
}