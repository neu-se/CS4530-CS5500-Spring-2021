import * as React from "react";
import {useEffect, useState} from "react";
import {Button, FormControl, FormLabel, Heading, IconButton, Input, Text, useToast, VStack} from "@chakra-ui/react";
import {AiFillHeart, AiOutlineDelete, AiOutlineHeart} from "react-icons/ai";
import {useForm} from "react-hook-form";

interface TodoItem {
    title: string;
    id: number;
}

interface FormContents {
    itemDesc: string;
}

const TodoItemComponent:
    React.FunctionComponent<{ item: TodoItem, deleteItem: () => void }>
    = ({item, deleteItem}) => {
    const [isLiked, setLiked] = useState<boolean>(false);
    let likeButton;
    if (isLiked) {
        likeButton = <IconButton aria-label="unlike" icon={<AiFillHeart/>}
                                 onClick={() => {
                                     setLiked(false)
                                 }}/>
    } else {
        likeButton = <IconButton aria-label="like" icon={<AiOutlineHeart/>}
                                 onClick={() => setLiked(true)}/>
    }
    return <Text> {item.title}
        <Button onClick={deleteItem}><AiOutlineDelete/></Button>
        {likeButton}
    </Text>;
}
export const TodoApp = () => {
    const [items, setItems] = useState<TodoItem[]>([{title: "Add your first item", id: 0}])
    const [numberOfTimesClosed, setNumberOfTimesClosed] = useState<number>(0);

    const toast = useToast();
    const {register, handleSubmit, reset} = useForm<FormContents>();

    function onSubmit(contents: FormContents) {
        console.log('Got submit!');
        console.log(contents.itemDesc);
        if(contents.itemDesc){ //It's possible to trigger the onSubmit handler before the form is reset. This will make that be a no-op, instead of inserting an undefined entry into the list
            // setItems(items.concat({title:contents.itemDesc})); //Bad: we can lose updates since `items` might be stale
            const newItem = {title: contents.itemDesc, id: Date.now()};
            setItems(oldItems => oldItems.concat(newItem)); //Good: uses state update function, no stale value for `items` since we don't use it!
            reset();
        }
    }

    const doSubmit = handleSubmit(onSubmit);


    // useEffect(() => {
    //     console.log("UseEffect triggered")
    //     toast({
    //         title: "TodoApp useEffect called",
    //         description: `You already went through ${numberOfTimesClosed} toasts!`,
    //         status: "warning",
    //         duration: 9000,
    //         isClosable: true,
    //         // onCloseComplete: () => {
    //         //     console.log('You clicked close!')
    //         //     // setNumberOfTimesClosed(numberOfTimesClosed + 1); // bad: loses count of increments
    //         //
    //         //     // good: when this function runs to update the state, it will at that very moment check
    //         //     // and compute new value from old value, instead of using stale
    //         //     setNumberOfTimesClosed((previousNumberOfTimesClosed ) => {
    //         //         return previousNumberOfTimesClosed + 1;
    //         //     })
    //         // }
    //     })
    // })
    useEffect(() => {
        toast({
            title: "Your items have changed!!",
            status: "success",
            duration: 9000,
            isClosable: true,
        })
    }, [items]);
    // console.log("Rendering todo app")
    // toast({
    //     title: "TodoApp function called",
    //     status: "warning",
    //     duration: 9000,
    //     isClosable: true,
    // })
    const deleteAllItems = () => {

        // // Never call setItems, so react doesn't know to re-render
        // while(items.length > 0){
        //     items.pop();
        // }
        // setItems(items);
        setItems([]);
    }

    return <VStack>
        <Heading>TODO List with Extensions</Heading>
        <p>You clicked close: {numberOfTimesClosed}</p>
        <p><Button color="red" onClick={deleteAllItems}>Delete all items</Button></p>
        <form onSubmit={doSubmit}>
            <FormControl id="itemDesc" isRequired>
                <FormLabel>TODO item:</FormLabel>
                <Input ref={register}
                       name="itemDesc"
                       placeholder="Put TODO description here"/>
            </FormControl>
            <Button type="submit">Add TODO item</Button>
        </form>
        {items.map((theItem) =>
            <TodoItemComponent
                item={theItem}
                key={theItem.id}
                deleteItem={() => {
                    setItems(oldItems => oldItems.filter((i) => i !== theItem))
                }}
            />)
        }

    </VStack>;
}
