import myPromise from './promiseMaker'

async function driver(flag: boolean) {
    const promiseName = `myPromise(${flag})`
    try {
        console.log(`A: starting driver(${flag})`)
        console.log(`A: now awaiting ${promiseName}(${flag})`)        
        const n = await myPromise(promiseName, flag, 7)
        console.log(`B: ${promiseName} fulfilled and passed ${n} to its successor`);
    } catch (n) {
        console.log(`C: ${promiseName} rejected and passed "${n}" to its successor`)
    }
}

driver(true)
driver(false)

console.log('main handler finished') 
