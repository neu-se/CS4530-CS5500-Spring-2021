import myPromise from './promiseMaker'

const p1 = myPromise("p1",true,10).then(n => {console.log("p1 finishing"); return n})

async function ghost() {
    try {
        const n = await p1
        console.log("n =",n)
        const m = await p1
        console.log("m =",m)
    } catch {}
}
        
ghost()


