async function foo() {
    const succeeder = new Promise((resolve) => setTimeout(() => resolve('1'), 1000))
    const failer = new Promise((_,reject) => setTimeout(() => reject('2'), 500))
    let result1 = await succeeder
    let result2 = await failer
    
    
 }
 foo().catch(() => {}) // Attempt to swallow all errors...