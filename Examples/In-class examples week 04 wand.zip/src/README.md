Here are the examples from Professor Wand's 2/11/21 class, plus a whole lot more, including some that are unfinished.  

Think of them as brain teasers-- you can try to predict what they will do, or try to explain what they actually do.

Or think of them as puzzle pieces that you can rearrange for fun.  Or a chemistry set with many colored bottles that you can mix (and hope they don't explode).

In any case, enjoy!
