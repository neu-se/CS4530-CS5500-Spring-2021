import myPromiseMaker from './promiseMaker'
    
const p1 = myPromiseMaker("p1",true,10)
console.log('A p1 =', p1)
const p2 = p1.then(n => {
    console.log('B p2 =', p2);
    console.log('B p1 now =', p1)
    // create a p1.catch() promise here, and return it, or assign it to a 
    // shared variable.
})
const p3 = p1.catch(n => {
    console.log('C p3 =', p3);
    console.log('C p1 now =', p1)
})


console.log('D p2 = ', p2)
console.log('D p3 = ', p3)