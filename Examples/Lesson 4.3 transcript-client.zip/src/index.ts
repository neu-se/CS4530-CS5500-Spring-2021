import * as ds from './dataService';
import { Transcript } from './types';

console.log('starting index.ts');

async function script1() {
  try {
    console.log('starting script1()');
    const p1 = await ds.getTranscript(2);
    console.log('script1 says: getTranscript(2) says:', p1);
    const blakeIDs = await ds.getStudentIDs('blake');
    console.log('script1 says: students named blake:', blakeIDs);
    try {
      await (ds.addGrade(blakeIDs[0], 'cs101', 85));
    } catch {console.log("script1 says: blake's grade already there, continuing");}
    console.log('script1 says', await ds.getGrade(blakeIDs[0], 'cs101'));
    console.log('script1 succeeded');
  } catch { console.log('script1 failed'); }
}


async function getTranscriptsByName(studentName: string) {
  try {
    console.log(`starting getTranscriptsByName(${studentName})`);
    const ids = await ds.getStudentIDs(studentName);
    // put out all the requests in parallel, not sequentially
    // requests becomes an array of promises
    const requests : Promise<Transcript>[] = ids.map(id => ds.getTranscript(id));
    const transcripts = await Promise.all(requests);
    console.log(`getTranscriptsByName says: ${studentName}'s transcripts:`, transcripts);
    console.log('getTranscriptsByName succeeded');
  } catch {
    console.log('getTranscriptsByName failed');
  }
}

script1(); // this will be done asynchronously
// this is printed right away.  Creates a promise that will be fulfilled later.
console.log(getTranscriptsByName('blake'));

console.log('index.ts done');