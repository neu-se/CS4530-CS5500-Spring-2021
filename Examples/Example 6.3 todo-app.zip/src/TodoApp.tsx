import * as React from "react";
import {
    VStack, Text, Heading, Input, Button, FormControl, FormLabel
} from "@chakra-ui/react";
import { AiOutlineDelete } from "react-icons/ai";
import { useForm } from "react-hook-form";

interface TodoItem {
    title: string;
}

interface FormContents {
    itemDesc : string;
}


export const TodoApp = () => {
    const [items, setItems] = React.useState<TodoItem[]>([{title:"Add your first item"}])
    const {register, handleSubmit, reset} = useForm<FormContents>();

    function onSubmit(contents : FormContents) {
        console.log('Got submit!');
        // setItems(items.concat({title:contents.itemDesc}));
        const newItem = {title:contents.itemDesc};
        setItems(oldItems => oldItems.concat(newItem));
        reset();
    }

    const doSubmit = handleSubmit(onSubmit);

    function renderItem(it:TodoItem, index:number) {
        function onClick(e:any) {
            console.log('got click!');
            setItems(oldItems => oldItems.filter((i) => i !== it))
        }
        return <Text key={index}> {it.title} <Button onClick={onClick}><AiOutlineDelete/></Button></Text>;
    }
    
    return <VStack>
        <Heading>TODO List</Heading>
        <form onSubmit={doSubmit}>
            <FormControl id="itemDesc" isRequired>
                <FormLabel>TODO item:</FormLabel>
                <Input ref={register}
                    name="itemDesc" 
                    placeholder="Put TODO description here" />
            </FormControl>
            <Button type="submit">Add TODO item</Button>
        </form>
        { items.map(renderItem) }

    </VStack>;
}
