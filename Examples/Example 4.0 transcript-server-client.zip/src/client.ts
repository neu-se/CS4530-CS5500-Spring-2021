import axios, {AxiosResponse} from 'axios';
import * as fsPromises from "fs/promises";
//Write your sample/testing code for the client in this file, or call any of the methods in this file to see them run
//Run this file with `npm run client`


async function axiosAwaitExample() {
  try {
    const response = await axios.get('https://rest-example.covey.town/')
    console.log('Heard back from server');
    console.log(response.data);
  } catch (err) {
    console.log("Uh oh!");
    console.trace(err);
  }
}

function axiosPromiseExample() {
  axios.get('https://rest-example.covey.town/').then(response => {
    console.log('Heard back from server');
    console.log(response.data);
  }).catch(err => {
    console.log("Uh oh!");
    console.trace(err);
  });
}

axiosAwaitExample();


function runClientPromises() {
  console.log('Making a requests');
  const studentIDs = [1, 2, 3, 4];
  const promisesForTranscripts = studentIDs.map(
    studentID => axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
      .then((response) =>
        fsPromises.writeFile(`transcript-${response.data.student.studentID}.json`, JSON.stringify(response.data))
      ));
  return Promise.all(promisesForTranscripts).then(results => {
    const statsPromises = studentIDs.map(studentID => fsPromises.stat(`transcript-${studentID}.json`));
    return Promise.all(statsPromises).then(stats => {
      const totalSize = stats.reduce((runningTotal, val) => runningTotal + val.size, 0);
      console.log(`Finished calculating size: ${totalSize}`);
    });
  }).then(() => {
    console.log('Done');
  });
  console.log('Requests sent!');
}
function runClientPromisesErrorHandlers() {
  console.log('Making a requests');
  const studentIDs = [1, 2, 3, 4];
  const promisesForTranscripts = studentIDs.map(
    studentID => axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
      .then((response) =>
        fsPromises.writeFile(`transcript-${response.data.student.studentID}.json`, JSON.stringify(response.data))
      ));
  return Promise.all(promisesForTranscripts).then(results => {
    const statsPromises = studentIDs.map(studentID => fsPromises.stat(`transcript-${studentID}.json`));
    return Promise.all(statsPromises).then(stats => {
      const totalSize = stats.reduce((runningTotal, val) => runningTotal + val.size, 0);
      console.log(`Finished calculating size: ${totalSize}`);
    });
  }).then(() => {
    console.log('Done');
  });
  console.log('Requests sent!');
}

async function runClientAsync() {
  console.log('Making a requests');
  const studentIDs = [1, 2, 3, 4];
  const promisesForTranscripts = studentIDs.map(
    async (studentID) => {
      const response = await axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
      await fsPromises.writeFile(`transcript-${response.data.student.studentID}.json`, JSON.stringify(response.data))
    });
  console.log('Requests sent!');
  await Promise.all(promisesForTranscripts);
  const stats = await Promise.all(studentIDs.map(studentID => fsPromises.stat(`transcript-${studentID}.json`)));
  const totalSize = stats.reduce((runningTotal, val) => runningTotal + val.size, 0);
  console.log(`Finished calculating size: ${totalSize}`);
  console.log('Done');
}

async function runClientAsyncSerially() {
  console.log('Making a requests');
  const studentIDs = [1, 2, 3, 4];
  for (let studentID of studentIDs) {
    const response = await axios.get(`https://rest-example.covey.town/transcripts/${studentID}`);
    await fsPromises.writeFile(`transcript-${response.data.student.studentID}.json`, JSON.stringify(response.data))
  }
  let totalSize = 0;
  for (let studentID of studentIDs) {
    const stats = await fsPromises.stat(`transcript-${studentID}.json`);
    totalSize += stats.size;
  }
  console.log(`Finished calculating size: ${totalSize}`);
}

