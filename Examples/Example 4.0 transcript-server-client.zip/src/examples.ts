import axios from 'axios';
import {promises as fsPromises} from 'fs';
import * as client from './client';
import {Transcript} from "./transcriptManager";

// Write your sample/testing code for the client in this file, or call any of the methods in this file to see them run
// Run this file with `npm run client`
function timedPromise(): Promise<number> {
  return new Promise<number>((resolve, reject) => {
    const random = Math.random();
    if (random < 0.5)
      setTimeout(() => {
        reject(random);
      }, 1000);
    else
      setTimeout(() => {
        resolve(random);
      }, 1000);
  });
}

const myPromise = timedPromise();
myPromise.then((val) => {
  console.log(`Promise succeeded with ${val}`)
  myPromise.then(val => {
    console.log(`I ran it again and got ${val}`)
  })
}).catch(val => {
  console.error(`Promise failed with ${val}`)
})

// This is a very bad way to compute Pi, but it's good for an example because it takes a long time!
function approximatePi(count) {
  let inside = 0;
  const r = 5;
  console.log(`Approximating Pi using ${count} iterations`)
  for (let i = 0; i < count; i++) {
    const x = Math.random() * r * 2 - r;
    const y = Math.random() * r * 2 - r;
    if ((x * x + y * y) < r * r) {
      inside++
    }
  }
  const ret = 4.0 * inside / count;
  console.log(`Computed: ${ret}`);
  return ret;
}

//Some examples that call the wrapper client
async function script1() {
  try {
    console.log('starting script1()');
    const p1 = await client.getTranscript(2);
    console.log('script1 says: getTranscript(2) says:', p1);
    const blakeIDs = await client.getStudentIDs('blake');
    console.log('script1 says: students named blake:', blakeIDs);
    try {
      await (client.addGrade(blakeIDs[0], 'cs101', 85));
    } catch {
      console.log("script1 says: blake's grade already there, continuing");
    }
    console.log('script1 says', await client.getGrade(blakeIDs[0], 'cs101'));
    console.log('script1 succeeded');
  } catch {
    console.log('script1 failed');
  }

}

async function getTranscriptsByName(studentName: string) {
  try {
    console.log(`starting getTranscriptsByName(${studentName})`);
    const ids = await client.getStudentIDs(studentName);
    // put out all the requests in parallel, not sequentially
    // requests becomes an array of promises
    const requests: Promise<Transcript>[] = ids.map(id => client.getTranscript(id));
    const transcripts = await Promise.all(requests);
    console.log(`getTranscriptsByName says: ${studentName}'s transcripts:`, transcripts);
    console.log('getTranscriptsByName succeeded');
  } catch {
    console.log('getTranscriptsByName failed');
  }
}


// Here are a bunch of examples that call axios directly

// Example from Monday, uses Axios. You can use this code to help figure out the last part of the activity,
// but make sure that your code uses the client in `client.ts` instead of axios.
async function transcriptServerCreateStudentAndPostGrades() {
  const newStudent = await axios.post('https://rest-example.covey.town/transcripts', {name: 'Prof Bell'});
  const newStudentID = newStudent.data.studentID;
  const grades = [
    {course: 'CS4530-0', grade: 100},
    {course: 'CS4500-1', grade: 80},
    {course: 'CS4530-2', grade: 100},
    {course: 'CS4500-3', grade: 80},
    {course: 'CS4530-4', grade: 100},
    {course: 'CS4500-5', grade: 80},
    {course: 'CS4530-6', grade: 100},
    {course: 'CS4500-7', grade: 80},
    {course: 'CS4530-8', grade: 100},
    {course: 'CS4500-9', grade: 80},
  ];
  const promises = [];
  for (const grade of grades) {
    console.log(`Filing grade for ${grade.course}`);
    promises.push(axios.post(`https://rest-example.covey.town/transcripts/${newStudentID}/${grade.course}`,
      {grade: grade.grade}));
  }
  await Promise.all(promises); //can't proceed to get transcript until after all new grades are posted
  const transcript = await axios.get(`https://rest-example.covey.town/transcripts/${newStudentID}`);
  console.log(transcript.data);
  return transcript.data;
}

async function axiosAwaitExample() {
  try {
    const response = await axios.get('https://rest-example.covey.town/');
    console.log('Heard back from server');
    console.log(response.data);
  } catch (err) {
    console.log('Uh oh!');
    console.trace(err);
  }
}

function axiosPromiseExample() {
  axios.get('https://rest-example.covey.town/').then(response => {
    console.log('Heard back from server');
    console.log(response.data);
  }).catch(err => {
    console.log('Uh oh!');
    console.trace(err);
  });
}


function runClientPromises() {
  console.log('Making a requests');
  const studentIDs = [1, 2, 3, 4];
  const promisesForTranscripts = studentIDs.map(
    studentID => axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
      .then((response) =>
        fsPromises.writeFile(`transcript-${response.data.student.studentID}.json`, JSON.stringify(response.data)),
      ));
  return Promise.all(promisesForTranscripts).then(results => {
    const statsPromises = studentIDs.map(studentID => fsPromises.stat(`transcript-${studentID}.json`));
    return Promise.all(statsPromises).then(stats => {
      const totalSize = stats.reduce((runningTotal, val) => runningTotal + val.size, 0);
      console.log(`Finished calculating size: ${totalSize}`);
    });
  }).then(() => {
    console.log('Done');
  });
  console.log('Requests sent!');
}

function runClientPromisesErrorHandlers() {
  console.log('Making a requests');
  const studentIDs = [1, 2, 3, 4];
  const promisesForTranscripts = studentIDs.map(
    studentID => axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
      .then((response) =>
        fsPromises.writeFile(`transcript-${response.data.student.studentID}.json`, JSON.stringify(response.data)),
      ));
  return Promise.all(promisesForTranscripts).then(results => {
    const statsPromises = studentIDs.map(studentID => fsPromises.stat(`transcript-${studentID}.json`));
    return Promise.all(statsPromises).then(stats => {
      const totalSize = stats.reduce((runningTotal, val) => runningTotal + val.size, 0);
      console.log(`Finished calculating size: ${totalSize}`);
    });
  }).then(() => {
    console.log('Done');
  });
  console.log('Requests sent!');
}

async function runClientAsync() {
  console.log('Making a requests');
  const studentIDs = [1, 2, 3, 4];
  const promisesForTranscripts = studentIDs.map(
    async (studentID) => {
      const response = await axios.get(`https://rest-example.covey.town/transcripts/${studentID}`);
      await fsPromises.writeFile(`transcript-${response.data.student.studentID}.json`, JSON.stringify(response.data));
    });
  console.log('Requests sent!');
  await Promise.all(promisesForTranscripts);
  const stats = await Promise.all(studentIDs.map(studentID => fsPromises.stat(`transcript-${studentID}.json`)));
  const totalSize = stats.reduce((runningTotal, val) => runningTotal + val.size, 0);
  console.log(`Finished calculating size: ${totalSize}`);
  console.log('Done');
}

async function runClientAsyncSerially() {
  console.log('Making a requests');
  const studentIDs = [1, 2, 3, 4];
  for (const studentID of studentIDs) {
    const response = await axios.get(`https://rest-example.covey.town/transcripts/${studentID}`);
    await fsPromises.writeFile(`transcript-${response.data.student.studentID}.json`, JSON.stringify(response.data));
  }
  let totalSize = 0;
  for (const studentID of studentIDs) {
    const stats = await fsPromises.stat(`transcript-${studentID}.json`);
    totalSize += stats.size;
  }
  console.log(`Finished calculating size: ${totalSize}`);
}

