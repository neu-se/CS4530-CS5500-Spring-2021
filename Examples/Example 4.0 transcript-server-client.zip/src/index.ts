import * as client from './client';
import {Transcript} from "./transcriptManager";

//Some examples that call the wrapper client
async function script1() {
    try {
        console.log('starting script1()');
        const p1 = await client.getTranscript(2);
        console.log('script1 says: getTranscript(2) says:', p1);
        const blakeIDs = await client.getStudentIDs('blake');
        console.log('script1 says: students named blake:', blakeIDs);
        try {
            await (client.addGrade(blakeIDs[0], 'cs101', 85));
        } catch {
            console.log("script1 says: blake's grade already there, continuing");
        }
        console.log('script1 says', await client.getGrade(blakeIDs[0], 'cs101'));
        console.log('script1 succeeded');
    } catch {
        console.log('script1 failed');
    }

}

async function getTranscriptsByName(studentName: string) {
    try {
        console.log(`starting getTranscriptsByName(${studentName})`);
        const ids = await client.getStudentIDs(studentName);
        // put out all the requests in parallel, not sequentially
        // requests becomes an array of promises
        const requests: Promise<Transcript>[] = ids.map(id => client.getTranscript(id));
        const transcripts = await Promise.all(requests);
        console.log(`getTranscriptsByName says: ${studentName}'s transcripts:`, transcripts);
        console.log('getTranscriptsByName succeeded');
    } catch {
        console.log('getTranscriptsByName failed');
    }
}

// this creates a new promise that will executed when the scheduler
// gets around to it
script1();
// getTranscriptsByName() creates a promise that will be fulfilled later. 
// But the console.log runs right away. So it prints "Promise<pending>" 
console.log(getTranscriptsByName('blake'));
// also done right away
console.log('index.ts done');