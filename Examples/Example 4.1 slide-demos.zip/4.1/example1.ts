console.log("main event handler running")
setTimeout(() => {
    console.log("event handler 2 running")
    console.log("event handler 2 finishing")
})
console.log("main event handler finishing")
