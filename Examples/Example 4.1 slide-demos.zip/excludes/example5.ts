console.log("main thread starting")
const p2 = new Promise<number>((resolve) => {
    console.log("creating new thread p2..")
    setTimeout(() => {
        console.log("thread p2 starting")
        console.log("thread p2 finishing\n")
        resolve(10)
    })
    console.log("promise exiting")
})

const p3 = p2.then((n) => {
    console.log("starting p3 with", n);
    console.log("p3 finishing\n");
    return (n + 10)
})

const p4 = p3.then((n) => {
    console.log("starting p4 with", n);
    console.log("p4 finishing\n")
})

console.log("main thread finishing\n")

export { }