function exercise(flag: boolean) {
    console.log(`creating new thread p2[${flag}]`)
    const p2 = new Promise<number>((fulfill, reject) => {
        setTimeout(() => {
            console.log(`thread p2[${flag}] starting`)
            if (flag) {
                console.log(`thread p2[${flag}] fulfilling with 10\n`);
                fulfill(10)
            } else {
                console.log(`thread p2[${flag}] rejecting with 18\n`);
                reject(18)
            }
        })
    })
    console.log(`creating new thread p3[${flag}]`)
    const p3 = p2
        .then((n => console.log(`p3 says p2[${flag}] fulfilled with ${n}\n`)))
        .catch(
        (m => console.log(`p3 says p2[${flag}] rejected with ${m}\n`))
    )
}    

exercise(true)
exercise(false)

console.log(`main thread finishing\n`)
    


// const p4 = p2.then((n) => {
//     console.log(`starting p4 with`, n);
//     console.log(`p4 finishing with`, n+20, `\n`);
//     return (n + 20)
// })
// // a comment to copy
// const p5 = Promise.all([p4,p3]).then((values) => {
//     console.log(`p5 starting with`, values)})


//

export { }