async function f1(flag: boolean) {
    console.log(`creating new thread f1[${flag}]`)
    try {
        const n = await f2 (flag);
        console.log(`f1[${flag}] says f2[${flag}] fulfilled with ${n}`)
    } catch (m) {
        console.log(`f1[${flag}] says f2[${flag}] rejected with message "${m}"`)
    }
    console.log(`f1[${flag}] finishing\n`)
}
   
// f2(flag) resolves or rejects depending on the value of the flag
async function f2 (flag: boolean) {
    console.log(`creating new thread for f2[${flag}]`)
    return new Promise ((fulfill, reject) => {       
        setTimeout(() => {
            console.log(`f2[${flag}] running`)
            if (flag) {           
                fulfill(12)
            } else {
            reject ("the flag was false")
            }
        })
    })
}        

async function driver(flag:boolean){
    console.log(`calling f1[${flag}] (async/await)`)
    try {await f1(flag)} catch (e) {console.log(e)}
    console.log(`driver(${flag}) finished\n`)
}

driver(true);
driver(false);

console.log(`main thread finishing\n`)
    



