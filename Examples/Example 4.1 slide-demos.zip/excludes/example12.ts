// a promise that might fail

function f(callback: (arg0:number) => boolean) {
    return new Promise<number>((resolve, reject) => {
        if (callback(3)) { resolve(10) }
        else { reject("f(3) failed") }
    })
}

function alwaysTrue(n:number){return true}
function alwaysFalse(n:number){return false}
function alwaysThrowsError(n:number):boolean{throw new Error(`error value was ${n}`)}

f(alwaysTrue).then(n => console.log(`f(alwaysTrue) returned ${n}`))

f(alwaysFalse).catch(n => console.log(`f(alwaysFalse) returned ${n}`))

f(alwaysThrowsError).catch(reason => console.log(`catch block received ${reason}`))


