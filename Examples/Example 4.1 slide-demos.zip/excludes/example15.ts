async function p2 (flag: boolean) : Promise<number> {
    console.log(`creating new thread p2[${flag}]`)
    return new Promise<number>((fulfill, reject) => {       
        setTimeout(() => {
            console.log(`thread p2[${flag}] starting`)
            if (flag) {
                console.log(`thread p2[${flag}] fulfilling with 10\n`);
                fulfill(10)
            } else {
            console.log(`thread p2[${flag}] throws an error\n`)
            reject (`thread p2[${flag}] rejected\n`)
            }
        })
    })     
}    

async function p3(flag: boolean) {
    console.log(`creating new thread p3[${flag}]`)
    try {
        const n = await p2(flag);
        console.log(`p3 says p2[${flag}] fulfilled with ${n}\n`)
    } catch (m) {
        console.log(`p3 says p2[${flag}] rejected with ${m}\n`)
    }
}
    
p3(true)
p3(false)

console.log(`main thread finishing\n`)
    



