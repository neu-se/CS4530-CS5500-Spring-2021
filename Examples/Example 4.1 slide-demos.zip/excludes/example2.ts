// simplest illustration of threads

console.log("main thread running")

const p1 = new Promise((resolve) => {
    console.log("this part is run immediately")
    console.log("creating new thread...")
    setTimeout(() => {
        console.log("thread 2 running")
        console.log("thread 2 finishing")
    })
    console.log("promise exiting")
})

console.log("main thread finishing")

export {}