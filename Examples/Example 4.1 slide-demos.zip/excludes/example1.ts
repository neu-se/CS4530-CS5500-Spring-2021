// simplest illustration of handlers

console.log("main handler running")
setTimeout(() => {
    console.log("handler 2 running")
    console.log("handler 2 finishing")
})
console.log("main handler finishing")

export {}
