console.log("main thread starting")
const p2 = new Promise<number>((resolve) => {
    console.log("creating new thread p2..")
    setTimeout(() => {
        console.log("thread p2 starting")
        console.log("thread p2 finishing with 10\n")
        resolve(10)
    })
    console.log("promise exiting")
})

const p3 = p2.then((n) => {
    console.log("starting p3 with", n);
    console.log("p3 finishing with", n+10, "\n");
    return (n + 10)
})

const p4 = p2.then((n) => {
    console.log("starting p4 with", n);
    console.log("p4 finishing with", n+20, "\n");
    return (n + 20)
})
// a comment to copy
const p5 = Promise.all([p4,p3]).then((values) => {
    console.log("p5 starting with", values)})


console.log("main thread finishing\n")

export { }