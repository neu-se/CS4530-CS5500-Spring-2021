// dealing with failure
console.log("creating new thread p2")
const p2 = new Promise<number>((resolve, reject) => {
        setTimeout(() => {
        console.log("thread p2 starting")
        console.log("thread p2 rejecting with 10\n")
        reject(10)
        })
    })
    

console.log("creating new thread p3")  
const p3 = p2.then(
    (n => console.log('p3 says p2 fulfilled with', n)),
    (m => console.log("p3 says p2 rejected with", m))
)

console.log("main thread finishing\n")
    


// const p4 = p2.then((n) => {
//     console.log("starting p4 with", n);
//     console.log("p4 finishing with", n+20, "\n");
//     return (n + 20)
// })
// // a comment to copy
// const p5 = Promise.all([p4,p3]).then((values) => {
//     console.log("p5 starting with", values)})


//

export { }