import {assert} from 'chai'
import * as db from './transcriptManager'

function test1 () {
    db.initialize();
    const id1 = db.addStudent("avery");
    const id2 = db.addStudent("blair");
    const id3 = db.addStudent("blair");
    const ids = db.getStudentIDs("blair")
    assert.sameMembers(ids, [id2, id3], "getStudentIDs should return all the matching IDs");
    db.addGrade(id1,"cs100",85)
    assert.equal(db.getGrade(id1,"cs100"),85,"getGrade should return the right answer")
    assert.throws(() => db.addGrade(id1,"cs100",37),
        "student 1 already has a grade in course cs100",
    )
}

// not testing all the error behaviors yet.

// test deleteStudent
function testDeleteStudent() {
    db.initialize();
    const idAvery1 = db.addStudent("avery")
    const idAvery2 = db.addStudent("avery")
    const ids = db.getStudentIDs("avery")
    assert.sameMembers(ids, [idAvery1, idAvery2],
        "students not installed properly");
    db.deleteStudent(idAvery1);
    assert.sameMembers(db.getStudentIDs("avery"),
        [idAvery2], "avery1 not removed"
    )
}




describe("first tests", () => {
    it("first test", test1)
    it("test of delete", testDeleteStudent)

})