
import React from 'react';
import youtube from '../apis/youtube';

class Comments extends React.Component {

  state = { comments: [] };

  async getAllComments() {
    // const commentThreads = await youtube.get('/commentThreads', {
    //   params: {
    //     part: 'snippet',
    //     videoId: this.props.video.id.videoId
    //   }
    // });

    // const comments = commentThreads.data.items.map(comment => { return {
    //     textDisplay: comment.snippet.topLevelComment.snippet.textDisplay, 
    //     id: comment.snippet.topLevelComment.id,
    //     img: comment.snippet.topLevelComment.snippet.authorProfileImageUrl,
    //     author: comment.snippet.topLevelComment.snippet.authorDisplayName, 
    //   };
    // });
    // this.setState({ comments: comments });
  }

  async deleteComment(id) {
    console.log('deleting comment: ', id);
    const response = await youtube.delete('/comments', {
      params: {
        id: id
      }
    });
    this.getAllComments();
  }

  componentDidUpdate(prevProps) {
    if (this.props.video && ((prevProps.video && this.props.video.id.videoId !== prevProps.video.id.videoId) || !prevProps.video)) {
      this.getAllComments();
    }
  }

  render() {
    if(!this.state.comments) {
      return (<div></div>)
    }
    const displayComments = this.state.comments.map(comment => {
      return (<div className="ui grid" key={comment.id}>
        <div className="one wide column">
          <img src={comment.img} />
        </div>
        <div className="fourteen wide column">
          <p><strong>{comment.author}</strong></p>
          <p>{comment.textDisplay}</p>
        </div>
        <div className="one wide column">
          <i className="users delete icon" onClick={() => { this.deleteComment(comment.id) } }></i>
        </div>
      </div>)
    });
    return (
      <div>
        <h2>Comments</h2>
        {displayComments}
      </div>    
    )
  }

}

export default Comments;
