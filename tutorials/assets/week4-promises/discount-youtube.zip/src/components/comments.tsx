
import React from 'react';
import axios from 'axios'; // eslint-disable-line @typescript-eslint/no-unused-vars
import youtube from '../apis/youtube'; // eslint-disable-line @typescript-eslint/no-unused-vars

class Comments extends React.Component<any, any> {

  state = { comments: [] };

  async getAllComments() {
    // Axios code to fetch and update comments goes here
  }

  async deleteComment(id: string) {
    console.log('deleting comment: ', id);
    await youtube.delete('/comments', {
      params: {
        id: id
      }
    });
    this.getAllComments();
  }

  componentDidUpdate(prevProps: any) {
    if (this.props.video && ((prevProps.video && this.props.video.id.videoId !== prevProps.video.id.videoId) || !prevProps.video)) {
      this.getAllComments();
    }
  }

  render() {
    if(!this.state.comments) {
      return (<div></div>)
    }
    const displayComments = this.state.comments.map((comment: any) => {
      return (<div className="ui grid" key={comment.id}>
        <div className="one wide column">
          <img alt="avatar" src={comment.img} />
        </div>
        <div className="fourteen wide column">
          <p><strong>{comment.author}</strong></p>
          <p>{comment.textDisplay}</p>
        </div>
        <div className="one wide column">
          <i className="users delete icon" onClick={() => { this.deleteComment(comment.id) } }></i>
        </div>
      </div>)
    });
    return (
      <div>
        <h2>Comments</h2>
        {displayComments}
      </div>    
    )
  }

}

export default Comments;
