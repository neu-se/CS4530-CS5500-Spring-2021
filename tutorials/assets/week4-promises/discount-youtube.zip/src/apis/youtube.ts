
import axios from 'axios';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const API_KEY = ''; // Add your API key here. 

export default axios.create({ /* Axios default config goes here */ });
