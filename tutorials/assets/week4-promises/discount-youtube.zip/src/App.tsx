
import React from 'react';
import SearchBar from './components/search-bar';
import VideoList from './components/video-list';
import VideoDetail from './components/video-detail';
import Comments from './components/comments';
import axios from 'axios'; // eslint-disable-line @typescript-eslint/no-unused-vars
import youtube from './apis/youtube'; // eslint-disable-line @typescript-eslint/no-unused-vars

class App extends React.Component<any, any> {

  state = { videos: [], selectedVideo: null };

  searchYoutubeVideos = async (searchTerm: any) => {
   // Axios code to search and update youtube results goes here
  }

  updateSelectedVideo = (selectedVideo: any) => {
    this.setState({ selectedVideo: selectedVideo });
  }

  componentDidMount() {
    this.searchYoutubeVideos('Javascript event loop explained')
  }

  render() {
    return (
      <div className="ui container">
        <h1> Youtube Video Streaming App </h1>
        <SearchBar searchYoutubeVideos={this.searchYoutubeVideos} />
        <div className="ui grid">
          <div className="ui row">
            <div className="eleven wide column">
              <VideoDetail video={this.state.selectedVideo} />
              <br></br>
              <hr></hr>
              <Comments video={this.state.selectedVideo} />
            </div>
            <div className="five wide column">
              <h3>Recommended for you: </h3>
              <VideoList videos={this.state.videos} updateSelectedVideo={this.updateSelectedVideo} />
            </div>
          </div>
        </div>
      </div>
    )
  }

}

export default App;
