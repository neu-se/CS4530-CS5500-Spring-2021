
import React from 'react';
import SearchBar from './components/search-bar';
import VideoList from './components/video-list';
import VideoDetail from './components/video-detail';
import Comments from './components/comments';
import axios from 'axios';
import youtube from './apis/youtube';

class App extends React.Component {

  state = { videos: [], selectedVideo: null };

  searchYoutubeVideos = async (searchTerm: any) => {
    // const response = await youtube.get('/search', {
    //   params: {
    //     q: searchTerm
    //   }
    // });
    // this.setState({ videos: response.data.items });
    // if(!this.state.selectedVideo) {
    //   this.setState({ selectedVideo: { ...response.data.items[0], ...{ id: { videoId: 'ZPIoYnIHbbA' } } } });
    // }
    axios.get('https://www.googleapis.com/youtube/v3/search', {
        params: {
          part: 'snippet',
          maxResults: 10,
          key: 'AIzaSyCghhuO7OwHrXOBlYd67CqGxmwswskvgL8',
          q: searchTerm
        }
      }).then(response => {
        this.setState({ videos: response.data.items }); // setState is React stuff and can be ignored for now.
        if(!this.state.selectedVideo) {
          this.setState({ selectedVideo: response.data.items[0] });
        }
      });
  }

  updateSelectedVideo = (selectedVideo: any) => {
    this.setState({ selectedVideo: selectedVideo });
  }

  componentDidMount() {
    this.searchYoutubeVideos('Javascript event loop explained')
  }

  render() {
    return (
      <div className="ui container">
        <h1> Youtube Video Streaming App </h1>
        <SearchBar searchYoutubeVideos={this.searchYoutubeVideos} />
        <div className="ui grid">
          <div className="ui row">
            <div className="eleven wide column">
              <VideoDetail video={this.state.selectedVideo} />
              <br></br>
              <hr></hr>
              <Comments video={this.state.selectedVideo} />
            </div>
            <div className="five wide column">
              <h3>Recommended for you: </h3>
              <VideoList videos={this.state.videos} updateSelectedVideo={this.updateSelectedVideo} />
            </div>
          </div>
        </div>
      </div>
    )
  }

}

export default App;
