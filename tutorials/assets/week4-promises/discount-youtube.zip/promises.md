Log into your google account at: https://console.developers.google.com/

1. developer console home.
2. create project.
3. add information.
4. create.

dashboard
select project
enable api and services
youtube data api v3

create credentials
configure credentials
  - youtube api v3
  - web browser (javascript)
  - public

what credentials do I need?

copy key
