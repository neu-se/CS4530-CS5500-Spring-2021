
import { useEffect } from 'react';
import { Button } from "@chakra-ui/react"
import { makeSelectCount } from './store/count/selectors';
import { useDispatch, useSelector } from 'react-redux';
import { createSelector } from 'reselect';
import { IncrementCount } from './store/count/actions';

const stateSelector = createSelector(makeSelectCount, (count) => ({count}));
const actionDispatch = (dispatch: any): any => ({
  incrementCount: () => dispatch(IncrementCount())
});

function Counter() {
  
  const { count } = useSelector(stateSelector);
  const { incrementCount } = actionDispatch(useDispatch());

  useEffect(() => {
    console.log(`The current count is ${count}`);
  }, [count]);

  function incrementCountHandler() {
    incrementCount();
  }

  return (
    <div>
      <h1>Count: {count}</h1>
      <Button colorScheme="teal" onClick={incrementCountHandler}>Click me!</Button>
    </div>
  );

}

export default Counter;
