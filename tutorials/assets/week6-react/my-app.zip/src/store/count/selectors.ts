
import { createSelector } from 'reselect';

const counterState = (state: any) => state.count;

export const makeSelectCount = createSelector(counterState, (counter: any) => counter.count);
