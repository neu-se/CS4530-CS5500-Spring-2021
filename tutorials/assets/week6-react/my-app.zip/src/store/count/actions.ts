
export enum ActionTypes {
  'INCREMENT' = 'INCREMENT',
  'DECREMENT' = 'DECREMENT'
};

export function IncrementCount() {
  return { type: ActionTypes.INCREMENT };
}

export function DecrementCount() {
  return { type: ActionTypes.DECREMENT };
}

export type Actions = {
  type: ActionTypes,
  payload?: any
};
