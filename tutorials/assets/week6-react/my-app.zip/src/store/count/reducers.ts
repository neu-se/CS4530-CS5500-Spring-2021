
import { Actions, ActionTypes } from './actions';

const defaultState = {
  count: 0
};

export default function countReducer(state = defaultState, action: Actions) {
  switch(action.type) {
    case ActionTypes.INCREMENT:
      return { ...state, count: state.count + 1 };
    case ActionTypes.DECREMENT:
      return { ...state, count: state.count - 1 };
    default:
      console.log(state);
      return state;
  }
}

