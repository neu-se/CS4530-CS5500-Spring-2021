
import { createStore, combineReducers } from 'redux';
import countReducer from './count/reducers';

const reducers = combineReducers({ count: countReducer });

export default createStore(reducers);
