import React from 'react';
import './App.css';
import Header from './Header';
import Counter from './Counter';
import { Box, Button, ChakraProvider, Flex, Heading } from '@chakra-ui/react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

function App() {
  return (
    <ChakraProvider>
        <Router>
        <Flex align="center" mr={5}>
          <Button colorScheme="twitter">
            <Heading as="h1" size="lg" letterSpacing={"-.1rem"}>
              <Link to="/header">Header</Link>
            </Heading>
          </Button>
          <Button colorScheme="purple">
            <Heading as="h1" size="lg" letterSpacing={"-.1rem"}>
              <Link to="/counter">Counter</Link>
            </Heading>
          </Button>
        </Flex>
          <div className="App">
            <Switch>
              <Route path="/header" render={() => (
                <header className="App-header">
                  <Header />
                  <Header name="John" />
                  <Header name="Jane" />
                </header>
              )}>
              </Route>
              <Route path="/counter">
                <Counter />
              </Route>
            </Switch>
          </div>
        </Router>
    </ChakraProvider>
  );
}

export default App;
