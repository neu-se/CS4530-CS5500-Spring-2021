
function Header(props: {name?: string}) {

  return (
    <h1> Hello, {props.name} </h1>
  );

}

Header.defaultProps = {
  name: 'World'
};

export default Header;
