import React, { useEffect } from 'react';
import 'semantic-ui-css/semantic.min.css'
import './App.css';
import { ChakraProvider, Heading } from '@chakra-ui/react';
import VideoDetail from './components/video-detail';
import Comments from './components/comments';
import SearchBar from './components/search-bar';
import VideoList from './components/video-list';
import { useSelector, useDispatch } from "react-redux";
import { createSelector } from "reselect";
import { makeSelectVideo } from "./store/selectors";
import { UpdateComments, UpdateSelectedVideo, UpdateVideos } from './store/actions';
import { DataService } from './services/data.service';

const stateSelector = createSelector(makeSelectVideo, (video: any) => ({
  videos: video.videos,
  selectedVideo: video.selectedVideo,
  comments: video.comments
}));

const actionDispatch = (dispatch: any): any => ({
  updateVideos: (videos: any) => dispatch(UpdateVideos(videos)),
  updateSelectedVideo: (selectedVideo: any) => dispatch(UpdateSelectedVideo(selectedVideo)),
  updateComments: (comments: any) => dispatch(UpdateComments(comments))
});


function App() {
  
  const { selectedVideo } = useSelector(stateSelector);
  const { updateVideos, updateSelectedVideo, updateComments } = actionDispatch(useDispatch());

  function searchYoutubeVideos(searchTerm: any) {
    DataService.searchVideos(searchTerm)
      .then((data) => {
        if(!selectedVideo) {
          selectVideo(data.items[0]);
        }
        updateVideos(data.items);
      });
  }
 
  function selectVideo(selectedVideo: any) {
    DataService.getComments(selectedVideo.id.videoId)
      .then((data) => {
        const comments = data.items.map((comment: any) => { return {
          textDisplay: comment.snippet.topLevelComment.snippet.textDisplay, 
          id: comment.snippet.topLevelComment.id,
          img: comment.snippet.topLevelComment.snippet.authorProfileImageUrl,
          author: comment.snippet.topLevelComment.snippet.authorDisplayName, 
        };
      });
        updateSelectedVideo(selectedVideo);
        updateComments(comments);
        console.log('App.tsx: ', comments);
      });
  }

  useEffect(() => {
    if(!selectedVideo) {
      searchYoutubeVideos('Matt Lange - Isorhythm')
    }
  });

  return (
    <ChakraProvider>
      <div className="ui container">
        <Heading> Youtube Video Streaming App </Heading>
        <SearchBar searchYoutubeVideos={searchYoutubeVideos} />
        <div className="ui grid">
          <div className="ui row">
            <div className="eleven wide column">
              <VideoDetail />
              <br></br>
              <hr></hr>
              <Comments />
            </div>
            <div className="five wide column">
              <Heading as="h3" size="lg">Recommended for you: </Heading>
              <VideoList updateSelectedVideo={selectVideo} />
            </div>
          </div>
        </div>
      </div>
    </ChakraProvider>
  );
}

export default App;
