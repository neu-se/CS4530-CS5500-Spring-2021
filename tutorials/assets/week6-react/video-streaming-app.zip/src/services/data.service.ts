
import youtube from '../apis/youtube';

export class DataService {

  public static searchVideos(searchTerm: string) {
    return youtube.get('/search', {
      params: {
         q: searchTerm
      }
    }).then((response) => response.data);
  }

  public static getComments(videoId: string) {
    return youtube.get('/commentThreads', {
      params: {
        videoId: videoId,
      }
    }).then((response) => response.data);
  }

}
