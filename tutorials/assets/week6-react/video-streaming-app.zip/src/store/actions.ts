
export enum ActionTypes {
  'UPDATE_VIDEOS' = 'UPDATE_VIDEOS',
  'UPDATE_SELECTED_VIDEO' = 'UPDATE_SELECTED_VIDEO',
  'UPDATE_COMMENTS' = 'UPDATE_COMMENTS'
};

export function UpdateVideos(videos: Array<any>) {
  return { type: ActionTypes.UPDATE_VIDEOS, payload: videos };
}

export function UpdateSelectedVideo(selectedVideo: any) {
  return { type: ActionTypes.UPDATE_SELECTED_VIDEO, payload: selectedVideo };
}

export function UpdateComments(comments: Array<any>) {
  return { type: ActionTypes.UPDATE_COMMENTS, payload: comments };
}

export type Actions = {
  type: ActionTypes,
  payload?: any
};
