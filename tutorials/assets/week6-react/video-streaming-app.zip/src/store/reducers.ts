import { ActionTypes, Actions } from './actions';

const defaultState = {
  videos: [],
  selectedVideo: null,
  comments: []
};

export default function countReducer(state = defaultState, action: Actions) {
  switch(action.type) {
    case ActionTypes.UPDATE_VIDEOS:
      return { ...state, videos: action.payload };
    case ActionTypes.UPDATE_SELECTED_VIDEO:
      return { ...state, selectedVideo: action.payload };
    case ActionTypes.UPDATE_COMMENTS:
        return { ...state, comments: action.payload }
    default:
      return state;
  }
}
