
import { createStore, combineReducers } from 'redux';
import videoReducer from './reducers';

const reducers = combineReducers({ video: videoReducer });

export default createStore(reducers);
