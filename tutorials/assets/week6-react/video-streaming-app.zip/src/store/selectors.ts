
import { createSelector } from 'reselect';

const videoState = (state: any) => state.video;

export const makeSelectVideo = createSelector(videoState, (video: any) => video);
