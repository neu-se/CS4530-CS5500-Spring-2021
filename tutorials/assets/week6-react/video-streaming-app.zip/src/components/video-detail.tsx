
import { useSelector } from "react-redux";
import { createSelector } from "reselect";
import { makeSelectVideo } from "../store/selectors";

const stateSelector = createSelector(makeSelectVideo, (video: any) => ({
  selectedVideo: video.selectedVideo,
}));

function VideoDetail() {

    const { selectedVideo } = useSelector(stateSelector);

    if(!selectedVideo) {
      return (<div>Loading...</div>)
    }

    const videoSrc = `https://www.youtube.com/embed/${selectedVideo.id.videoId}`;
    return (
      <div>
        <div className="ui embed">
          <iframe title={selectedVideo.id.videoId} src={videoSrc} />
        </div>
        <div className="ui segment">
          <h4 className="ui header">{selectedVideo.snippet.title}</h4>
          <p>{selectedVideo.snippet.description}</p>
        </div>
        
      </div>
    )

}

export default VideoDetail;
