
import React from 'react';
import youtube from '../apis/youtube'; // eslint-disable-line @typescript-eslint/no-unused-vars
import { useSelector } from "react-redux";
import { createSelector } from "reselect";
import { makeSelectVideo } from "../store/selectors";
import { Heading } from '@chakra-ui/react';

const stateSelector = createSelector(makeSelectVideo, (video: any) => ({
  comments: video.comments,
}));

function Comments() {

  const { comments } = useSelector(stateSelector);

  // async deleteComment(id: string) {
  //   console.log('deleting comment: ', id);
  //   await youtube.delete('/comments', {
  //     params: {
  //       id: id
  //     }
  //   });
  //   this.getAllComments();
  // }

  if(!comments) {
    return (<div></div>)
  }

  console.log('comments.tsx: ', comments);

  const displayComments = comments.map((comment: any) => {
    return (<div className="ui grid" key={comment.id}>
      <div className="one wide column">
        <img alt="avatar" src={comment.img} />
      </div>
      <div className="fourteen wide column">
        <p><strong>{comment.author}</strong></p>
        <p>{comment.textDisplay}</p>
      </div>
      <div className="one wide column">
        <i className="users delete icon" /* onClick={() => { deleteComment(comment.id) } } */></i>
      </div>
    </div>)
  });
  
  return (
    <div>
      <Heading as="h2" size="lg">Comments</Heading>
      <br />
      {displayComments}
    </div>    
  );

}

export default Comments;
