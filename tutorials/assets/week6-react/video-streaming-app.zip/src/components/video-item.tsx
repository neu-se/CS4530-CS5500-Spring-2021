
import React from 'react';
import './video-item.css';

function VideoItem(props: any) {

  function onVideoSelect() {
    props.updateSelectedVideo(props.video);
  }

  return (
    <div onClick={onVideoSelect} className="video-item item">
      <img alt={props.video.snippet.title}
        className="ui image"
        src={props.video.snippet.thumbnails.medium.url}
      />
      <div className="content">
        <div className="header"> {props.video.snippet.title} </div>
      </div>
    </div>
  );

}

export default VideoItem;
