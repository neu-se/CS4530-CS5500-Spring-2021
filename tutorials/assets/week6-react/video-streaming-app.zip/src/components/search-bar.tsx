
import { useState } from "react";

function SearchBar(props: any) {
  
  const [searchTerm, setSearchTerm] = useState('');

  function onInputChange(event: any) {
    setSearchTerm(event.target.value)
  }

  function onFormSubmit(event: any) {
    event.preventDefault();
    props.searchYoutubeVideos(searchTerm);
  }

  return (
    <div className="search-bar ui segment">
      <form onSubmit={onFormSubmit} className="ui form">
        <div className="field">
          <label> Video Search </label>
          <input type="text" value={searchTerm} onChange={onInputChange} />
        </div>
      </form>
    </div>
  );

}

export default SearchBar;
