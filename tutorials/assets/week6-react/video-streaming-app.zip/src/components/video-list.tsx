
import React from 'react';
import VideoItem from './video-item';
import { useSelector } from "react-redux";
import { createSelector } from "reselect";
import { makeSelectVideo } from "../store/selectors";

const stateSelector = createSelector(makeSelectVideo, (video: any) => ({
  videos: video.videos,
}));


function VideoList(props: any) {

  const { videos } = useSelector(stateSelector);

  let videoList = videos.map((video: any) => {
    return <VideoItem key={video.id.videoId} video={video} updateSelectedVideo={props.updateSelectedVideo} />
  });

  return (
    <div className="ui relaxed divided list">
      {videoList}
    </div>
  );

}

export default VideoList;
